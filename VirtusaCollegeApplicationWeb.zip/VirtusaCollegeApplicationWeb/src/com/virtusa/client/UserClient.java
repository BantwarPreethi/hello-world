package com.virtusa.client;

import com.virtusa.view.AdminView;
import com.virtusa.view.UserView;
public class UserClient {
	public UserClient() {
		
	}

	public static void main(String[] args) {
		//AdminView adminView = new AdminView();
		//adminView.adminView();
		UserView.mainMenu();
}

}      
     