package com.virtusa.entities;

public class Departments {

}
        