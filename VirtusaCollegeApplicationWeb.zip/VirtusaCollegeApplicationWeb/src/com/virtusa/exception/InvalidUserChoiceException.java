package com.virtusa.exception;

public class InvalidUserChoiceException extends RuntimeException
{
	public String toString()
	{
		return "---------Entered Choice is Invalid---------------";
	}

}
      