package com.virtusa.client;

import com.virtusa.view.StudentView;

public class StudentMainView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentView studentView=new StudentView();
		studentView.studentMenu();
	}
             
}
